import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informacion-pago',
  templateUrl: './informacion-pago.component.html',
})
export class InformacionPagoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

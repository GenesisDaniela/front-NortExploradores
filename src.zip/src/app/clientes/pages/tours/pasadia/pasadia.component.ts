import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pasadia',
  templateUrl: './pasadia.component.html',
  styleUrls: ['./pasadia.component.css']
})
export class PasadiaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

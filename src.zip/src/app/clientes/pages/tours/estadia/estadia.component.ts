import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estadia',
  templateUrl: './estadia.component.html',
  styleUrls: ['./estadia.component.css']
})
export class EstadiaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

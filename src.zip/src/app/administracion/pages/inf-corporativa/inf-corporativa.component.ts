import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inf-corporativa',
  templateUrl: './inf-corporativa.component.html',
  styleUrls: ['./inf-corporativa.component.css']
})
export class InfCorporativaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

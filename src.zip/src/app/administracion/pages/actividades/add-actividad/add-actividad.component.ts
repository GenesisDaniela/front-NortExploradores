import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-actividad',
  templateUrl: './add-actividad.component.html',
  styleUrls: ['./add-actividad.component.css']
})
export class AddActividadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

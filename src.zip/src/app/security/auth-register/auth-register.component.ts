import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-register',
  templateUrl: './auth-register.component.html',
})
export class AuthRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
